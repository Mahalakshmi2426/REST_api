const express = require("express");
const {connectMongoDb} = require("./connection");

const {logReqRes} = require("./middlewares");

const userRouter = require("./routes/user");
const authRouter = require("./routes/auth");
require("dotenv").config();


const app = express();
const PORT = 8000;

//connection with mongodb
connectMongoDb("mongodb://127.0.0.1:27017/ev_stations").then(() => console.log("MongoDB connecetd"))

//schema


//middleware 
app.use(express.json());
app.use(express.urlencoded({extended: false}))

app.use(logReqRes("log.txt"));

//routes
app.use("/api/users", userRouter); 
app.use("/api/auth", authRouter);



// app.get("/test", (req, res) => {
//   res.send("Server is working!");
// });



app.listen(PORT, () => console.log(`server started at port: ${PORT}`));