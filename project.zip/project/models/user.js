const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");

const userSchema = new mongoose.Schema({
  Name: {
    type: String,
    required: true,
  },
  Email: { 
    type: String, 
    required: true, 
    unique: true 
  }, // Add email
  Password: { 
    type: String, 
    required: true 
  },
  Latitude: {
    type: Number ,
    required: true,
  },
  Longitude: {
    type: Number,
    required: true,
  },
  Status: {
    type: String,
    required: true,
  },
  PowerOutputKW: {
    type: Number,
    required: true,
  },
  ConnectorType:{
    type: String,
    required: true,
  }
}, {timestamps: true}
);

userSchema.pre("save", async function(next) {
  if (!this.isModified("Password")) return next();
  this.Password = await bcrypt.hash(this.Password, 10);
  next();
});


const User = mongoose.model("user", userSchema); 

module.exports = User;