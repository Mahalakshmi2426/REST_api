const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/user');
require("dotenv").config();

const JWT_SECRET = process.env.JWT_SECRET;

if (!JWT_SECRET) {
  throw new Error("JWT_SECRET is not defined in environment variables");
}

async function handleRegister(req, res) {
  const { Name, Email, Password, Latitude, Longitude, Status, PowerOutputKW, ConnectorType } = req.body;

  if (!Email || !Password || !Name) {
    return res.status(400).json({ message: "Name, Email and Password are required" });
  }

  try {
    const existingUser = await User.findOne({ Email });
    if (existingUser) {
      return res.status(409).json({ message: "User already exists" });
    }

    const user = await User.create({
      Name,
      Email,
      Password, // Will be hashed by the pre-save hook
      Latitude,
      Longitude,
      Status,
      PowerOutputKW,
      ConnectorType
    });

    const token = jwt.sign({ userId: user._id }, JWT_SECRET, { expiresIn: "1h" });

    return res.status(201).json({ 
      message: "User registered successfully",
      token,
      user: {
        id: user._id,
        Name: user.Name,
        Email: user.Email
      }
    });
  } catch (error) {
    console.error("Registration error:", error);
    return res.status(500).json({ message: "Server error", error: error.message });
  }
}

async function handleLogin(req, res) {
  const { Email, Password } = req.body;

  if (!Email || !Password) {
    return res.status(400).json({ message: "Email and Password are required" });
  }

  try {
    const user = await User.findOne({ Email });
    if (!user) {
      return res.status(401).json({ message: "Invalid credentials" });
    }

    const isMatch = await bcrypt.compare(Password, user.Password);
    if (!isMatch) {
      return res.status(401).json({ message: "Invalid credentials" });
    }

    const token = jwt.sign({ userId: user._id }, JWT_SECRET, { expiresIn: "1h" });
    return res.json({ 
      token, 
      message: "Login successful",
      user: {
        id: user._id,
        Name: user.Name,
        Email: user.Email
      }
    });
    
  } catch (error) {
    console.error("Login error:", error);
    return res.status(500).json({ message: "Server error", error: error.message });
  }
}

module.exports = { handleRegister, handleLogin };